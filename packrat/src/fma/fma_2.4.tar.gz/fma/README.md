# fma

[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/fma)](https://cran.r-project.org/package=fma)
[![Downloads](http://cranlogs.r-pkg.org/badges/fma)](https://cran.r-project.org/package=fma)
[![Licence](https://img.shields.io/badge/licence-GPL--3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html)

An R package containing data from the book ["Forecasting: methods and applications" by Makridakis, Wheelwright and Hyndman (Wiley, 1998)](http://robjhyndman.com/forecasting/)


[![](https://robjhyndman.com/img/fma.jpg)](http://robjhyndman.com/forecasting/)
