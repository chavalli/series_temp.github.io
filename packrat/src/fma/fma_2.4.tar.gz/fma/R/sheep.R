

#' Sheep population
#'
#' Sheep population (in millions) of England and Wales: 1867--1939.
#'
#'
#' @format Time series data
#' @references Kendall (1976).
#' @source Makridakis, Wheelwright and Hyndman (1998) \emph{Forecasting:
#' methods and applications}, John Wiley & Sons: New York. Exercise 7.6.
#' @keywords datasets
#' @examples
#' tsdisplay(sheep)
#' @export

sheep <- stats::ts(c(2203, 2360, 2254, 2165, 2024, 2078, 2214, 2292,
2207, 2119, 2119, 2137, 2132, 1955, 1785, 1747, 1818, 1909, 1958,
1892, 1919, 1853, 1868, 1991, 2111, 2119, 1991, 1859, 1856, 1924,
1892, 1916, 1968, 1928, 1898, 1850, 1841, 1824, 1823, 1843, 1880,
1968, 2029, 1996, 1933, 1805, 1713, 1726, 1752, 1795, 1717, 1648,
1512, 1338, 1383, 1344, 1384, 1484, 1597, 1686, 1707, 1640, 1611,
1632, 1775, 1850, 1809, 1653, 1648, 1665, 1627, 1791,
1797),s=1867,f=1)
