

#' Number of minks trapped
#'
#' Annual number of minks trapped in McKenzie river district of northwest
#' Canada: 1848--1911.
#'
#'
#' @format Time series data
#' @source Makridakis, Wheelwright and Hyndman (1998) \emph{Forecasting:
#' methods and applications}, John Wiley & Sons: New York. Exercise 2.4.
#' @keywords datasets
#' @examples
#' tsdisplay(mink)
#' @export


mink <- stats::ts(c(37123, 34712, 29619, 21151, 24859, 25152, 42375,
50839, 61581, 61951, 76231, 63264, 44730, 31094, 49452, 43961,
61727, 60334, 51404, 58451, 73575, 74343, 27708, 31985, 39266,
44740, 60429, 72273, 79214, 79060, 84244, 62590, 35072, 36160,
45600, 47508, 52290, 110824, 76503, 64303, 83023, 40748, 35396,
29479, 42264, 58171, 50815, 51285, 70229, 76365, 70407, 41839,
45978, 47813, 57620, 66549, 54673, 55996, 60053, 39169, 21534,
17857, 21788, 33008),f=1,s=1848)
