FD_EXTERNAL
struct { double fltmin, fltmax, epsmin, epsmax; } machfd_;
